# Cross Compiler Script
# (C) "Menche", 2013 GPLv3
# Modifcations by Chris "Pentium44 / crazycoder13" Dorman, 2013
# Required for compile : GCC, SCons, G++, Git

# options to make. -j# should be set to the number of CPU cores + 1
export MAKEFLAGS="-j2"
export DIR=`pwd`

#Some Settings
irrlichtversion="1.7.2"
version="1.0"

# First, download and compile the cross-compiler
if [ ! -e mxe ]
then
	git clone -b master git://github.com/mxe/mxe.git
else
	cd mxe && git pull
	cd $DIR
fi

cd mxe
	git checkout master
	make $MAKEFLAGS gcc
cd $DIR

# environment variables for cross-compiling
export CC="$DIR/mxe/usr/bin/i686-pc-mingw32-gcc"
export CXX="$DIR/mxe/usr/bin/i686-pc-mingw32-g++"
export AR="$DIR/mxe/usr/bin/i686-pc-mingw32-ar"
export C_INCLUDE_PATH="$DIR/mxe/usr/i686-pc-mingw32/include"
export CMAKE_TOOLCHAIN="$DIR/mxe/usr/i686-pc-mingw32/share/cmake/mxe-conf.cmake"
export CFLAGS="-m32 -march=i686 -O2 -fomit-frame-pointer -pipe -D_FORTIFY_SOURCE=2"
export CXXFLAGS="-m32 -march=i686 -O2 -fomit-frame-pointer -pipe -D_FORTIFY_SOURCE=2"
export CPPFLAGS="-D_FORTIFY_SOURCE=2"

# Download the required libraries
if [ ! -e deps/irrlicht-$irrlichtversion/ ]
then
	cd deps
	wget http://downloads.sourceforge.net/irrlicht/irrlicht-$irrlichtversion.zip
	unzip irrlicht-$irrlichtversion.zip || return 1
	cd $DIR
fi

if [ ! -e deps/zlib-1.2.8/ ]
then
	cd deps
	wget http://zlib.net/zlib-1.2.8.tar.xz
	tar -xvf zlib-1.2.8.tar.xz || return 1
	cd $DIR
fi

if [ ! -e minetest-cc-$version-src/ ]
then
	wget http://cddo.us.to/minetest-cc/dl/minetest-cc-$version-src.tar.gz
	tar -xzf minetest-cc-$version-src.tar.gz || return 1
fi

# Build the required libraries
echo "Building Irrlicht $irrlichtversion"
cd deps/irrlicht-$irrlichtversion/source/Irrlicht/
make $MAKEFLAGS NDEBUG=1 win32 || return 1
cd $DIR

echo "Building Zlib"
cd deps/zlib-1.2.8
cmake . -DCMAKE_TOOLCHAIN_FILE=$CMAKE_TOOLCHAIN \
	-DCMAKE_C_FLAGS_RELEASE=-DNDEBUG || return 1
make $MAKEFLAGS || return 1
cd $DIR

# Get the minetest-cc source // Not needed
#if [ ! -e minetest-cc ]
#then
#	wget http://www.cddo.us/drive/users/Pentium44/M-CC/minetest-cc-1.0.tar.gz
#	tar -xvf minetest-cc-1.0.tar.gz || return 1
#fi

# Configure and build minetest-cc
echo "Building Minetest-CC"
cd minetest-cc-$version-src
sed -i "s/[\\][\\]/\//g" src/winresource.rc # Fix nasty Windoze paths <-- LOLOLOL
cmake . -DCMAKE_TOOLCHAIN_FILE=$CMAKE_TOOLCHAIN \
	-DCMAKE_INSTALL_PREFIX=/tmp \
	-DCMAKE_C_FLAGS_RELEASE=-DNDEBUG -DCMAKE_CXX_FLAGS_RELEASE=-DNDEBUG \
	-DBUILD_SERVER=0 \
	-DRUN_IN_PLACE=1 \
	-DIRRLICHT_INCLUDE_DIR=../deps/irrlicht-$irrlichtversion/include \
	-DIRRLICHT_LIBRARY=../deps/irrlicht-$irrlichtversion/lib/Win32-gcc/libIrrlicht.a \
	-DIRRLICHT_DLL=../deps/irrlicht-$irrlichtversion/bin/Win32-gcc/Irrlicht.dll \
	-DZLIB_INCLUDE_DIR=../deps/zlib-1.2.8 \
	-DZLIB_LIBRARIES=../deps/zlib-1.2.8/libzlib.dll \
	-DZLIB_DLL=../deps/zlib-1.2.8/libzlib.dll || return 1

make $MAKEFLAGS package || return 1

# Keep the environment clean!
unset DIR
unset CC
unset CXX
unset AR
unset C_INCLUDE_PATH
unset CFLAGS
unset CXXFLAGS
unset CPPFLAGS
unset MAKEFLAGS